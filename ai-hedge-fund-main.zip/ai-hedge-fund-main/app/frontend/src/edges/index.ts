import type { EdgeTypes } from '@xyflow/react';


export const edgeTypes = {
  // Add your custom edge types here!
} satisfies EdgeTypes;
